Refer to http://facerecog.github.io/version-merger/ for a full description.


